from django.shortcuts import render
from django.views.generic import TemplateView, CreateView
from .models import *


# Create your views here.

class Home(TemplateView):
    template_name = 'index.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["home_active"] = 'active'
        context['objects'] = Object.objects.all()
        return context


class About(TemplateView):
    template_name = 'about.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["about_active"] = 'active'
        return context


class Service(TemplateView):
    template_name = 'service.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["service_active"] = 'active'
        return context


class Real_estates(TemplateView):
    template_name = 'real_estate.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["real_es_active"] = 'active'
        context['objects'] = Object.objects.all()
        return context
    

def real_estate_detail(request, pk):
    real_estate_id = Object.objects.get(pk=pk)
    context = {'real_estate_id': real_estate_id,}
    return render(request, 'real_estate_detail.html', context)
    

class Sale_rent(TemplateView):
    template_name = 'sale_rent.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["sale_rt_active"] = 'active'
        return context


class Team(TemplateView):
    template_name = 'team.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["team_active"] = 'active'
        return context


class Testimonial(TemplateView):
    template_name = 'testimonial.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["testimonial_active"] = 'active'
        return context


class Contact(TemplateView):
    template_name = 'contact.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["contact_active"] = 'active'
        return context
