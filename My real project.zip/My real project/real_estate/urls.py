from django.urls import path
from real_estate.views import *

urlpatterns = [
    path('', Home.as_view(), name='home'),
    path('about/', About.as_view(), name='about'),
    path('service/', Service.as_view(), name='service'),
    path('real-estate/', Real_estates.as_view(), name='real_estate'),
    path('real-estate-detail/<int:pk>', real_estate_detail, name='real_estate_detail'),
    path('sale_rent/', Sale_rent.as_view(), name='sale_rent'),
    path('team/', Team.as_view(), name='team'),
    path('testimonial/', Testimonial.as_view(), name='testimonial'),
    path('contact/', Contact.as_view(), name='contact'),
]
