from django.db import models
from django.urls import reverse
from django.core.validators import MaxValueValidator, MinValueValidator, MaxLengthValidator
from django_admin_geomap import GeoItem

# Create your models here.

CITY = (
    ('Андижан', 'Андижан'),
    ('Ташкент', 'Ташкент '),
    ('Самарканд ', 'Самарканд'),
    ('Фергана', 'Фергана'),
    ('Бухара ', 'Бухара '),
    ('Навои', 'Навои'),
    ('Джизак', 'Джизак'),
    ('Гулистан', 'Гулистан'),
    ('Наманган', 'Наманган'),
    ('Хива', 'Хива'),
    ('Карши', 'Карши'),
    ('Нукус', 'Нукус'),
    ('Термез', 'Термез'),
)

SALE_RENT = (
    ("Продажа", "Продажа"),
    ("Аренда", "Аренда")
)

OBJECT_TYPE = (
    ('Квартира', 'Квартира'),
    ('Земельный участок', 'Земельный участок'),
    ('Участок земли', 'Участок земли'),
    ('Коттедж', 'Коттедж'),
    ('Дом', 'Дом'),
)


class Info(models.Model):
    location = models.CharField("Location", max_length=350)
    email = models.EmailField("Email", max_length=250)
    phone = models.CharField("Phone", max_length=15)
    twitter = models.TextField("Twitter")
    facebook = models.TextField("Facebook")
    youtube = models.TextField("Youtube")
    instagram = models.TextField("Instagram")

    class Meta:
        verbose_name = "Информация о Real Estate"
        verbose_name_plural = "Информация о Real Estate"

    def __str__(self):
        return 'Real Estates (info)'
    
class Picture(models.Model):
    picture = models.ImageField("Фото объекта", upload_to='Objects/')

    class Meta:
        verbose_name = "Фото объекта"
        verbose_name_plural = "Фото объекта"

    def image_admin_str(self, image):
        if image.image:
            return u'< img src="%s" width="100"/>' % image.image.url
        else:
            return None

    def get_absolute_url(self):
        return reverse("Picture_detail", kwargs={"pk": self.pk})


class Address(models.Model):
    address = models.CharField("Адрес", max_length=50)

    class Meta:
        verbose_name = "Адрес"
        verbose_name_plural = "Адрес"

    def __str__(self):
        return self.address

    def get_absolute_url(self):
        return reverse("Address_detail", kwargs={"pk": self.pk})


class Object(models.Model):
    sale_rent = models.CharField("Проадажа/Аренда", max_length=50, choices=SALE_RENT, default='Продажа', help_text='Выберите тип инвестиции')
    types = models.CharField("Тип объекта", max_length=50, choices=OBJECT_TYPE, help_text='Выберите тип объекта', default='Квартира')
    picture = models.ForeignKey(Picture, verbose_name="Фото объекта", on_delete=models.CASCADE, help_text='Картинка объекта')
    title = models.CharField("Название", max_length=150, help_text='Введите название объекта')
    price = models.FloatField("Цена", help_text='Введите цену объекта', validators=[MinValueValidator(0)])
    rooms_count = models.IntegerField("Количество комнат", validators=[MinValueValidator(0)], help_text='Введите количество комнат')
    area = models.CharField("Площадь", max_length=100, help_text='Введите площадь объекта')
    city = models.CharField("Город", max_length=50, choices=CITY, default='Ташкент')
    address = models.ForeignKey(Address, verbose_name="Адрес", on_delete=models.CASCADE, help_text='Выберите район')
    floors = models.IntegerField("Этаж", help_text='Введите количество или номер этажа')
    garage = models.BooleanField('Гараж',help_text='Имеется ли гараж')
    balcony = models.BooleanField("Балкон", help_text='Имеется ли балкон')
    repair = models.BooleanField("Ремонт", help_text='Имеется ли ремонт')
    about = models.TextField("Описание")
    created = models.DateTimeField("Создан", auto_now_add=True)
    updated = models.DateTimeField("Изменен", auto_now=True)
    publish = models.BooleanField("Выводить на главную страницу ?")

    class Meta:
        verbose_name = "Объект"
        verbose_name_plural = "Объекты"

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("Object_detail", kwargs={"pk": self.pk})
