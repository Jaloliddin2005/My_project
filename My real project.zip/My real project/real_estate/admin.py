from django.contrib import admin
from .models import *

# Register your models here.

class ObjectAdmin(admin.ModelAdmin):
    list_display = ['title', 'price', 'rooms_count', 'city', 'created', 'updated']

admin.site.register(Info)
admin.site.register(Picture)
admin.site.register(Address)
admin.site.register(Object, ObjectAdmin)