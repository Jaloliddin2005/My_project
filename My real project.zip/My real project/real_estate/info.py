info = {
    'location': 'Uzbekistan, Tashkent',
    'email': 'realestate@gmail.com',
    'phone': '+998 71 777 17 77',
}

social_media = {
    'twitter': 'https://twitter.com/',
    'facebook': 'https://www.facebook.com/',
    'youtube': 'https://www.youtube.com/',
    'instagram': 'https://www.instagram.com/',
}